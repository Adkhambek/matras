const { PORT, app } = require("./app");
app.listen(PORT, ()=> console.log(`Server is running on ${PORT} port`));